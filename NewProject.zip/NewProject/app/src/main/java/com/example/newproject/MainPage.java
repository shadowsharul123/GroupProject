package com.example.newproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class MainPage extends AppCompatActivity {

    private static final int RC_SIGN_OUT = 9001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        TextView welcomeTextView = findViewById(R.id.welcomeTextView);
        Button signOutButton = findViewById(R.id.btnSignOut);
        ImageButton reportButton = findViewById(R.id.btnReport);
        ImageButton aboutUsButton = findViewById(R.id.btnAboutUs);
        ImageButton newsButton = findViewById(R.id.btnNews);

        // Set OnClickListener for the about us button
        aboutUsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToAboutUsActivity();
            }
        });

        // Retrieve the Google account name from the intent
        String accountName = getIntent().getStringExtra("accountName");

        // Display the welcome message
//        welcomeTextView.setText("Welcome, " + accountName);

        // Set OnClickListener for the sign-out button
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signOutFromGoogle();
            }
        });
        // Set OnClickListener for the report button
        reportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToSubmitReportActivity();
            }
        });

        // Set OnClickListener for
        newsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToNewsActivity();
            }
        });
    }

    private void signOutFromGoogle() {
        // Build a GoogleSignInClient with the options specified by gso.
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        mGoogleSignInClient.signOut()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Sign-out was successful.
                            // Navigate to MainActivity after sign-out.
                            startActivity(new Intent(MainPage.this, MainActivity.class));
                            finish(); // Optional: Finish the MainPage activity to prevent going back.
                        } else {
                            // An error occurred during sign-out.
                            // Handle the error here if needed.
                        }
                    }
                });
    }
    private void redirectToSubmitReportActivity() {
        Intent intent = new Intent(MainPage.this, SubmitReport.class);
        startActivity(intent);
    }

    // Method to redirect to Profile1 activity
    private void redirectToAboutUsActivity() {
        Intent intent = new Intent(MainPage.this, AboutUs.class);
        startActivity(intent);
    }

    private void redirectToNewsActivity() {
        Intent intent = new Intent(MainPage.this, News.class);
        startActivity(intent);
    }

}
