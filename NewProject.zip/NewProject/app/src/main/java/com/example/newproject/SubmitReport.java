package com.example.newproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newproject.R;

import java.util.HashMap;
import java.util.Map;

public class SubmitReport extends AppCompatActivity {

    EditText etName, etEmail, etComment;
    final String URL = "http://192.168.68.102/comments/api.php";
    RequestQueue queue;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_report);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etComment = findViewById(R.id.etComment);

        queue = Volley.newRequestQueue(getApplicationContext());

        Button button = findViewById(R.id.btnSubmitComment);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Volley call
                makeRequest();
            }
        });
    }

    public void makeRequest() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Handle the response if needed
                redirectToMainPage();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                params.put("name", etName.getText().toString());
                params.put("email", etEmail.getText().toString());
                params.put("comments", etComment.getText().toString());

                return params;
            }
        };
        queue.add(stringRequest);
    }

    // Method to redirect to MainPage
    private void redirectToMainPage() {
        Intent intent = new Intent(this, MainPage.class);
        startActivity(intent);
        finish(); // Optional: Finish the SubmitReport activity to prevent going back.
    }
}