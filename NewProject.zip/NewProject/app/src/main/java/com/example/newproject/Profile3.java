package com.example.newproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class Profile3 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile3);

        Button ButtonBack3 = findViewById(R.id.btnBack3);

        // Set OnClickListener for the about us button
        ButtonBack3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToAboutUsActivity();
            }
        });

    }

    private void redirectToAboutUsActivity() {
        Intent intent = new Intent(Profile3.this, AboutUs.class);
        startActivity(intent);
    }
}
