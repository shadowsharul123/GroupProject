package com.example.newproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class Profile1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile1);

        Button ButtonBack = findViewById(R.id.btnBack1);

        // Set OnClickListener for the about us button
        ButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToAboutUsActivity();
            }
        });

    }

    private void redirectToAboutUsActivity() {
        Intent intent = new Intent(Profile1.this, AboutUs.class);
        startActivity(intent);
    }
}
