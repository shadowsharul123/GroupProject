package com.example.newproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.newproject.Profile1;
import com.example.newproject.R;

public class AboutUs extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aboutus);

        ImageButton ButtonSharul = findViewById(R.id.btnSharul);
        ImageButton ButtonPiqi = findViewById(R.id.btnPiqi);
        ImageButton ButtonHariz = findViewById(R.id.btnHariz);
        ImageButton ButtonZafran = findViewById(R.id.btnZafran);
        Button ButtonBack = findViewById(R.id.buttonBackk);


        // Set OnClickListener for the btnSharul ImageButton
        ButtonSharul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToProfile1Activity();
            }
        });

        ButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToMainPageActivity();
            }
        });

        ButtonPiqi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToProfile2Activity();
            }
        });

        ButtonHariz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToProfile3Activity();
            }
        });

        ButtonZafran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirectToProfile4Activity();
            }
        });
    }

    private void redirectToMainPageActivity() {
        Intent intent = new Intent(AboutUs.this, MainPage.class);
        startActivity(intent);
    }

    // Method to redirect to Profile1 activity
    private void redirectToProfile1Activity() {
        Intent intent = new Intent(AboutUs.this, Profile1.class);
        startActivity(intent);
    }

    private void redirectToProfile2Activity() {
        Intent intent = new Intent(AboutUs.this, Profile2.class);
        startActivity(intent);
    }

    private void redirectToProfile3Activity() {
        Intent intent = new Intent(AboutUs.this, Profile3.class);
        startActivity(intent);
    }

    private void redirectToProfile4Activity() {
        Intent intent = new Intent(AboutUs.this, Profile4.class);
        startActivity(intent);
    }
}
