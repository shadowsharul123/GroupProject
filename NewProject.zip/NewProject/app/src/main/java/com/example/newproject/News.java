package com.example.newproject;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;

import java.util.List;


import retrofit2.Call;
import retrofit2.Callback;
//import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class News extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NewsAdapter newsAdapter;

    public interface NewsApi {
        @GET("json_news.php")
        Call<List<NewsItem>> getNews();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create a Retrofit instance
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.68.102/comments/") // Replace with the base URL of your API
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        NewsApi newsApi = retrofit.create(NewsApi.class);

        // Make the network request
        Call<List<NewsItem>> call = newsApi.getNews();
        call.enqueue(new Callback<List<NewsItem>>() {

            @Override
            public void onResponse(Call<List<NewsItem>> call, retrofit2.Response<List<NewsItem>> response) {
                if (response.isSuccessful()) {
                    List<NewsItem> newsItems = response.body();
                    // Set up the RecyclerView adapter and display the news items
                    newsAdapter = new NewsAdapter(newsItems);
                    recyclerView.setAdapter(newsAdapter);
                } else {
                    // Handle the error, if needed
                }

            }

            @Override
            public void onFailure(Call<List<NewsItem>> call, Throwable t) {
                // Handle the failure, if needed
            }
        });



    }

}
